import type { Anime } from "./types";

// Sample anime data — 10 popular series with real poster/banner image URLs from CDN.
// Video URLs use Google's public sample videos (BigBuckBunny etc.) so the player
// actually plays something for demo purposes. Admin uploads replace these naturally.

// Public test video URLs that definitely play in HTML5 <video>
const SAMPLE_VIDEOS = {
  "1080p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "720p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "480p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
};

const sampleSources = (subDub: "Sub" | "Dub" | "Both" = "Sub") => [
  { quality: "1080p" as const, url: SAMPLE_VIDEOS["1080p"], label: "Main" },
  { quality: "720p" as const, url: SAMPLE_VIDEOS["720p"], label: "Backup" },
  { quality: "480p" as const, url: SAMPLE_VIDEOS["480p"], label: "Mobile" },
];

const makeEpisodes = (
  count: number,
  subDub: "Sub" | "Dub" | "Both" = "Sub",
  titlePattern = "Episode"
) =>
  Array.from({ length: count }, (_, i) => ({
    number: i + 1,
    title: `${titlePattern} ${i + 1}`,
    duration: "24m",
    subDub,
    sources: sampleSources(subDub),
  }));

export const SEED_ANIME: Anime[] = [
  {
    id: "a1",
    slug: "jujutsu-kaisen",
    title: "Jujutsu Kaisen",
    alternativeTitle: "呪術廻戦",
    poster:
      "https://image.tmdb.org/t/p/w500/fHpKWq9ayzSk8nSwqRuaAUemRKh.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/fHpKWq9ayzSk8nSwqRuaAUemRKh.jpg",
    synopsis:
      "Yuji Itadori is a boy with tremendous physical strength, though he lives a completely ordinary high school life. One day, to save a classmate who has been attacked by Curses, he eats the finger of the Dual-Faced Sorcerer, taking the Curse into his own soul. From then on, he shares his body with the King of Curses, Sukuna, and is inducted into Tokyo Jujutsu High School under the guidance of the powerful sorcerer Satoru Gojo. As Yuji trains alongside fellow students Megumi Fushiguro and Nobara Kugisaki, he is thrust into a hidden war between sorcerers and the Curses that threaten humanity. With each mission, the line between hero and monster blurs, and Yuji must confront what it truly means to be strong in a world built on suffering and sacrifice.",
    genres: ["Action", "Supernatural", "Shounen", "School"],
    type: "TV",
    studio: "MAPPA",
    year: 2020,
    status: "Airing",
    score: 8.7,
    ageRating: "R",
    popularityRank: 1,
    trailer: "https://www.youtube.com/watch?v=4A_X-Dvl0ws",
    episodes: makeEpisodes(12, "Both"),
    featured: true,
    trending: true,
    topAiring: true,
    createdAt: "2024-12-01T00:00:00.000Z",
  },
  {
    id: "a2",
    slug: "demon-slayer",
    title: "Demon Slayer: Kimetsu no Yaiba",
    alternativeTitle: "鬼滅の刃",
    poster:
      "https://image.tmdb.org/t/p/w500/xUfRZu2mi8jH6SzQEJGP6tjBuYj.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/nTvM4mhqNlHIvUk0N4y0fJT0z7a.jpg",
    synopsis:
      "Tanjiro Kamado returns home one day to find his entire family slaughtered by a demon, with only his sister Nezuko surviving — but transformed into a demon herself. Refusing to give up on his sister, Tanjiro sets out on a perilous journey to become a Demon Slayer, hoping to find a way to turn Nezuko back into a human and avenge his family. Along the way, he befriends the hot-tempered Zenitsu Agatsuma and the boar-masked Inosuke Hashibira, and trains under former Hashira Sakonji Urokodaki. The trio faces off against the Twelve Kizuki, the deadliest demons in service to Muzan Kibutsuji, the original demon who started it all. Tanjiro's unwavering compassion and his family's Hinokami Kagura become his greatest weapons in a war that has raged for a thousand years.",
    genres: ["Action", "Supernatural", "Adventure", "Shounen"],
    type: "TV",
    studio: "ufotable",
    year: 2019,
    status: "Airing",
    score: 8.5,
    ageRating: "R",
    popularityRank: 2,
    trailer: "https://www.youtube.com/watch?v=VQGCKyvzIM4",
    episodes: makeEpisodes(26, "Both"),
    featured: true,
    trending: true,
    topAiring: true,
    createdAt: "2024-11-15T00:00:00.000Z",
  },
  {
    id: "a3",
    slug: "attack-on-titan",
    title: "Attack on Titan",
    alternativeTitle: "進撃の巨人",
    poster:
      "https://image.tmdb.org/t/p/w500/hTP1DtLGFamjfu8WqjnuQdP1n4i.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/8OVxQ8g54UiZovBEs4ttjOyBwoF.jpg",
    synopsis:
      "Hundreds of years ago, humanity was driven to the brink of extinction by giant humanoid creatures called Titans, who devour humans seemingly without reason. The remnants of humanity built three concentric walls to protect themselves, and for a century lived in peace within Wall Maria. When the colossal Titan suddenly appears and breaches the outer wall, young Eren Yeager witnesses his mother being devoured by a Titan. Swearing vengeance, Eren enlists in the military along with his childhood friends Mikasa Ackerman and Armin Arlert. As they fight to reclaim their world, they uncover dark secrets hidden within the walls, the true nature of the Titans, and the brutal history that brought their civilization to this point. The war that begins as a simple revenge story evolves into a meditation on freedom, hatred, and the cost of survival.",
    genres: ["Action", "Drama", "Fantasy", "Mystery"],
    type: "TV",
    studio: "WIT Studio",
    year: 2013,
    status: "Completed",
    score: 9.1,
    ageRating: "R",
    popularityRank: 3,
    trailer: "https://www.youtube.com/watch?v=MGRm4IzK1SQ",
    episodes: makeEpisodes(25, "Sub"),
    featured: true,
    trending: true,
    topAiring: false,
    createdAt: "2024-10-20T00:00:00.000Z",
  },
  {
    id: "a4",
    slug: "one-piece",
    title: "One Piece",
    alternativeTitle: "ワンピース",
    poster:
      "https://image.tmdb.org/t/p/w500/cMD9Ygz11zjJzAovURpO75Qg7rT.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/uZNgyjQ6WXx5gDDLxT20zM3zVcc.jpg",
    synopsis:
      "Monkey D. Luffy refuses to let anyone or anything stand in the way of his quest to become the king of all pirates. With a rubber-powered body and a straw hat inherited from his idol Red-Haired Shanks, Luffy sets out from his small village to find the legendary treasure known as the One Piece. He assembles a crew of colorful misfits — swordsman Zoro, navigator Nami, sniper Usopp, cook Sanji, doctor Chopper, archaeologist Robin, shipwright Franky, and musician Brook — and together they sail the Grand Line, the most dangerous sea in the world. Along the way they face warlords, marines, emperors, and ancient conspiracies, all while Luffy's infectious dream draws allies from every corner of the globe. Twenty-five years of storytelling culminate in a single question: what is the One Piece, and what will finding it cost?",
    genres: ["Action", "Adventure", "Comedy", "Fantasy", "Shounen"],
    type: "TV",
    studio: "Toei Animation",
    year: 1999,
    status: "Airing",
    score: 8.9,
    ageRating: "PG-13",
    popularityRank: 4,
    trailer: "https://www.youtube.com/watch?v=S8_YwFLCh4U",
    episodes: makeEpisodes(20, "Both"),
    trending: true,
    topAiring: true,
    featured: false,
    createdAt: "2024-09-10T00:00:00.000Z",
  },
  {
    id: "a5",
    slug: "chainsaw-man",
    title: "Chainsaw Man",
    alternativeTitle: "チェンソーマン",
    poster:
      "https://image.tmdb.org/t/p/w500/npdB6eFzizki0WaZ1OvKcJrWe97.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/qjsuKHL6dRn8E1OYjBAa3rL0PYz.jpg",
    synopsis:
      "Denji is a teenage boy living with a chainsaw devil named Pochita, working as a devil hunter to pay off his deceased father's debt to the yakuza. When the yakuza betray and kill him, Pochita merges with Denji, granting him the power to transform parts of his body into chainsaws. Now a human-devil hybrid, Denji is recruited by the mysterious Makima into the Public Safety Devil Hunters, an elite government organization. As he learns to navigate a world of devils, hunters, and deadly politics, Denji discovers that his simple dreams — a slice of bread with jam, a warm bed, a girl to hold — are harder to reach than any victory over a devil. Brutal, surreal, and unexpectedly tender, Chainsaw Man is a meditation on desire, manipulation, and what it means to be human when your body is a weapon.",
    genres: ["Action", "Supernatural", "Horror", "Shounen"],
    type: "TV",
    studio: "MAPPA",
    year: 2022,
    status: "Airing",
    score: 8.5,
    ageRating: "R",
    popularityRank: 5,
    trailer: "https://www.youtube.com/watch?v=q15CRdE5Bv0",
    episodes: makeEpisodes(12, "Both"),
    featured: true,
    trending: true,
    topAiring: true,
    createdAt: "2024-12-10T00:00:00.000Z",
  },
  {
    id: "a6",
    slug: "spy-x-family",
    title: "Spy x Family",
    alternativeTitle: "スパイファミリー",
    poster:
      "https://image.tmdb.org/t/p/w500/1uzwC7y3jW9PoCmpjIB2oMmQFTQ.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/aA7vSjvNG3JZbCcv0EmS9YeGzWE.jpg",
    synopsis:
      "For the agent known only as Twilight, no order is too difficult to carry out. He is the Westalian Intelligence Services' best spy, a master of disguise who can become anyone, anywhere, for any mission. But when he is tasked with investigating the reclusive politician Donovan Desmond, he must do the one thing no spy should ever do — start a family. Adopting an orphan named Anya and marrying a civilian named Yor Briar, Twilight unknowingly assembles a household where each member hides a secret: his new daughter is a telepath who fled a research lab, and his new wife is a deadly assassin known as the Thorn Princess. Together they navigate the everyday chaos of family life while each secretly tries to protect the others from their own dangerous worlds. Heartwarming and hilarious, Spy x Family proves that the strongest bonds are the ones nobody planned.",
    genres: ["Action", "Comedy", "Slice of Life"],
    type: "TV",
    studio: "Wit Studio / CloverWorks",
    year: 2022,
    status: "Airing",
    score: 8.6,
    ageRating: "PG-13",
    popularityRank: 6,
    trailer: "https://www.youtube.com/watch?v=ofXigq9aIpo",
    episodes: makeEpisodes(25, "Both"),
    trending: true,
    topAiring: true,
    featured: false,
    createdAt: "2024-11-01T00:00:00.000Z",
  },
  {
    id: "a7",
    slug: "your-name",
    title: "Your Name",
    alternativeTitle: "君の名は。",
    poster:
      "https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babgKnONNoX.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/mMtUybQ6hL24FXo0F3Z4j2KG7kZ.jpg",
    synopsis:
      "Mitsuha Miyamizu is a high school girl living in the rural town of Itomori, dreaming of escaping her shrine-maiden duties for the excitement of Tokyo. Taki Tachibana is a high school boy in Tokyo, juggling his studies, his part-time job at an Italian restaurant, and his crush on a coworker. One morning, they wake up in each other's bodies — and the swap keeps happening, unpredictably, day after day. As they leave messages for each other and learn to navigate each other's lives, a deep bond forms across the impossible distance between them. But when the swaps suddenly stop, both Mitsuha and Taki realize that something far stranger than body-swapping is at play, and that the connection they built may be the only thing that can defy time, distance, and the heavens themselves to bring them together.",
    genres: ["Romance", "Drama", "Supernatural"],
    type: "Movie",
    studio: "CoMix Wave Films",
    year: 2016,
    status: "Completed",
    score: 8.9,
    ageRating: "PG",
    popularityRank: 7,
    trailer: "https://www.youtube.com/watch?v=xU47nhruN-Q",
    episodes: [
      {
        number: 1,
        title: "Your Name (Movie)",
        duration: "1h 46m",
        subDub: "Both",
        sources: sampleSources("Both"),
      },
    ],
    featured: false,
    trending: false,
    topAiring: false,
    createdAt: "2024-08-15T00:00:00.000Z",
  },
  {
    id: "a8",
    slug: "naruto-shippuden",
    title: "Naruto: Shippuden",
    alternativeTitle: "ナルト 疾風伝",
    poster:
      "https://image.tmdb.org/t/p/w500/zAYRe2bJxpWTVrwwmBc00VFkAf4.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/jvPMQ6u6x2jpbx7VJuOLpuMfwHE.jpg",
    synopsis:
      "Two and a half years have passed since Naruto Uzumaki left Konohagakure to train with the legendary sage Jiraiya. Now a teenager, he returns to his village stronger and wiser — but the threats he faces have grown just as much. The criminal organization Akatsuki, led by the mysterious Pain and the masked Tobi, is hunting the tailed beasts sealed inside the jinchūriki of every hidden village, including Naruto himself. As old enemies become allies and allies become enemies, Naruto must confront his destiny as the host of the Nine-Tailed Fox, the legacy of his parents, and the cycle of hatred that has cursed the shinobi world for generations. With Sasuke Uchiha still lost to vengeance, Naruto's promise to bring his friend home becomes the defining quest of his life — one that will reshape the entire ninja world.",
    genres: ["Action", "Adventure", "Shounen", "Supernatural"],
    type: "TV",
    studio: "Pierrot",
    year: 2007,
    status: "Completed",
    score: 8.3,
    ageRating: "PG-13",
    popularityRank: 8,
    trailer: "https://www.youtube.com/watch?v=1bqYP-Si4iQ",
    episodes: makeEpisodes(20, "Both"),
    trending: false,
    topAiring: false,
    featured: false,
    createdAt: "2024-07-20T00:00:00.000Z",
  },
  {
    id: "a9",
    slug: "death-note",
    title: "Death Note",
    alternativeTitle: "デスノート",
    poster:
      "https://image.tmdb.org/t/p/w500/g8hHbsRad4NRJzlPzPMQpUqgLE3.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/4yXOMHKfPpljDmW6JaqJiAiYSLr.jpg",
    synopsis:
      "Light Yagami is a brilliant high school student who one day finds a notebook dropped by a shinigami named Ryuk. The notebook — the Death Note — has the power to kill anyone whose name is written inside it, so long as the writer knows the victim's face. Driven by a god-complex and a hatred of injustice, Light begins executing criminals one by one, hoping to build a perfect world under his rule as the god Kira. But his killing spree attracts the attention of L, the world's greatest detective, an eccentric young man who agrees to help the international police task force hunt Kira down. What follows is a high-stakes game of cat and mouse between two geniuses, each willing to sacrifice everything to prove that their vision of justice is the right one. The line between hero and villain has rarely been this thin.",
    genres: ["Mystery", "Psychological", "Supernatural", "Thriller"],
    type: "TV",
    studio: "Madhouse",
    year: 2006,
    status: "Completed",
    score: 9.0,
    ageRating: "R",
    popularityRank: 9,
    trailer: "https://www.youtube.com/watch?v=NlJZ-YgAt-c",
    episodes: makeEpisodes(15, "Both"),
    trending: false,
    topAiring: false,
    featured: true,
    createdAt: "2024-06-10T00:00:00.000Z",
  },
  {
    id: "a10",
    slug: "hunter-x-hunter",
    title: "Hunter x Hunter",
    alternativeTitle: "ハンター×ハンター",
    poster:
      "https://image.tmdb.org/t/p/w500/le12bnLyq2KqQ1OQuSiF8Lr04SK.jpg",
    banner:
      "https://image.tmdb.org/t/p/original/wMl4lU0VtIjqUZHv3KKsZ4qDr0.jpg",
    synopsis:
      "Gon Freecss is a young boy who has spent his life on Whale Island with his aunt Mito, believing his father Ging abandoned him. When Gon learns that his father is actually a legendary Hunter — a licensed professional who travels the world seeking out rare treasures, hidden lands, and dangerous beasts — he resolves to follow in Ging's footsteps. To become a Hunter, Gon must pass the brutal Hunter Exam, a series of deadly challenges that test every facet of body and mind. Along the way he befriends the vengeful Kurapika, the aspiring doctor Leorio, and the former assassin Killua Zoldyck. Together they face worlds of magic, crime, and ancient conspiracies, learning that becoming a Hunter is less about the license and more about what you choose to hunt — and who you choose to protect.",
    genres: ["Action", "Adventure", "Fantasy", "Shounen"],
    type: "TV",
    studio: "Madhouse",
    year: 2011,
    status: "Completed",
    score: 9.0,
    ageRating: "PG-13",
    popularityRank: 10,
    trailer: "https://www.youtube.com/watch?v=D9iLEj4tUqk",
    episodes: makeEpisodes(20, "Sub"),
    trending: false,
    topAiring: false,
    featured: false,
    createdAt: "2024-05-01T00:00:00.000Z",
  },
];
