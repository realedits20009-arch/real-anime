// Navigation helpers — we use a single `/` route and switch views via query params.
// This keeps the site deployable as a static-friendly Next.js app on Vercel
// without needing per-route dynamic pages.

export type View =
  | { kind: "home" }
  | { kind: "detail"; slug: string }
  | { kind: "genre"; genre: string }
  | { kind: "search"; q: string }
  | { kind: "watchlist" }
  | { kind: "admin" };

export function parseView(searchParams: URLSearchParams): View {
  if (searchParams.has("admin")) return { kind: "admin" };
  if (searchParams.has("watchlist")) return { kind: "watchlist" };
  const anime = searchParams.get("anime");
  if (anime) return { kind: "detail", slug: anime };
  const genre = searchParams.get("genre");
  if (genre) return { kind: "genre", genre };
  const q = searchParams.get("q");
  if (q) return { kind: "search", q };
  return { kind: "home" };
}

export function viewToHref(view: View): string {
  switch (view.kind) {
    case "home":
      return "/";
    case "detail":
      return `/?anime=${encodeURIComponent(view.slug)}`;
    case "genre":
      return `/?genre=${encodeURIComponent(view.genre)}`;
    case "search":
      return `/?q=${encodeURIComponent(view.q)}`;
    case "watchlist":
      return "/?watchlist=1";
    case "admin":
      return "/?admin=1";
  }
}

// Helper to build a watch URL with the current episode preselected
export function watchHref(slug: string, episodeNumber?: number): string {
  const base = `/?anime=${encodeURIComponent(slug)}`;
  if (episodeNumber && episodeNumber > 0) {
    return `${base}&ep=${episodeNumber}`;
  }
  return base;
}

// Push a new view onto the URL using history API (client-side nav, no full reload)
export function navigate(view: View): void {
  if (typeof window === "undefined") return;
  const href = viewToHref(view);
  window.history.pushState({}, "", href);
  // Dispatch a custom event so the page router can re-render
  window.dispatchEvent(new PopStateEvent("popstate"));
}
