import type { Anime, UploadPayload, ContinueWatchingEntry } from "./types";
import { SEED_ANIME } from "./seed-data";

// ---- Storage keys ----
const ADMIN_UPLOADS_KEY = "real-anime:admin-uploads";
const WATCHLIST_KEY = "real-anime:watchlist";
const CONTINUE_WATCHING_KEY = "real-anime:continue-watching";

// ---- Utilities ----
export function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export function makeId(): string {
  return (
    "u" +
    Date.now().toString(36) +
    Math.random().toString(36).slice(2, 7)
  );
}

// ---- Combined catalog (seed + admin uploads from localStorage) ----
// Safe for SSR: returns just seed on server, merges client uploads on client.
export function getAllAnime(): Anime[] {
  if (typeof window === "undefined") return SEED_ANIME;
  const uploads = getAdminUploads();
  // uploads first so newest admin content shows at the top of "recently added"
  return [...uploads, ...SEED_ANIME];
}

export function getAnimeBySlug(slug: string): Anime | undefined {
  return getAllAnime().find((a) => a.slug === slug);
}

export function getAnimeById(id: string): Anime | undefined {
  return getAllAnime().find((a) => a.id === id);
}

export function getRelatedAnime(anime: Anime, limit = 6): Anime[] {
  const all = getAllAnime().filter((a) => a.id !== anime.id);
  const scored = all.map((a) => {
    const shared = a.genres.filter((g) => anime.genres.includes(g)).length;
    const sameType = a.type === anime.type ? 1 : 0;
    const sameStudio = a.studio === anime.studio ? 1 : 0;
    return { a, score: shared * 3 + sameType + sameStudio };
  });
  return scored
    .sort((x, y) => y.score - x.score || y.a.score - x.a.score)
    .slice(0, limit)
    .map((s) => s.a);
}

export function getAnimeByGenre(genre: string): Anime[] {
  return getAllAnime().filter((a) =>
    a.genres.some((g) => g.toLowerCase() === genre.toLowerCase())
  );
}

export function searchAnime(query: string): Anime[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  return getAllAnime().filter(
    (a) =>
      a.title.toLowerCase().includes(q) ||
      a.alternativeTitle?.toLowerCase().includes(q) ||
      a.studio.toLowerCase().includes(q) ||
      a.genres.some((g) => g.toLowerCase().includes(q))
  );
}

export function getFeatured(): Anime[] {
  return getAllAnime().filter((a) => a.featured);
}

export function getTrending(): Anime[] {
  return getAllAnime().filter((a) => a.trending);
}

export function getTopAiring(): Anime[] {
  return getAllAnime().filter((a) => a.topAiring);
}

export function getRecentlyAdded(limit = 12): Anime[] {
  return [...getAllAnime()]
    .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
    .slice(0, limit);
}

export function getAllGenresInUse(): string[] {
  const set = new Set<string>();
  getAllAnime().forEach((a) => a.genres.forEach((g) => set.add(g)));
  return Array.from(set).sort();
}

// ---- Admin uploads (localStorage) ----
export function getAdminUploads(): Anime[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(ADMIN_UPLOADS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveAdminUpload(anime: Anime): void {
  if (typeof window === "undefined") return;
  const uploads = getAdminUploads();
  uploads.unshift(anime);
  localStorage.setItem(ADMIN_UPLOADS_KEY, JSON.stringify(uploads));
}

export function deleteAdminUpload(id: string): void {
  if (typeof window === "undefined") return;
  const uploads = getAdminUploads().filter((a) => a.id !== id);
  localStorage.setItem(ADMIN_UPLOADS_KEY, JSON.stringify(uploads));
}

export function buildAnimeFromPayload(p: UploadPayload): Anime {
  return {
    id: makeId(),
    slug: slugify(p.title) || makeId(),
    title: p.title,
    alternativeTitle: p.alternativeTitle,
    poster: p.poster,
    banner: p.banner,
    synopsis: p.synopsis,
    genres: p.genres,
    type: p.type,
    studio: p.studio,
    year: p.year,
    status: p.status,
    score: p.score,
    ageRating: p.ageRating,
    popularityRank: p.popularityRank,
    trailer: p.trailer,
    episodes: p.episodes,
    featured: p.featured,
    trending: p.trending,
    topAiring: p.topAiring,
    createdAt: new Date().toISOString(),
  };
}

// ---- Watchlist (localStorage) ----
export function getWatchlist(): Anime[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(WATCHLIST_KEY);
    if (!raw) return [];
      const ids: string[] = JSON.parse(raw);
      return getAllAnime().filter((a) => ids.includes(a.id));
  } catch {
    return [];
  }
}

export function getWatchlistIds(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(WATCHLIST_KEY);
    if (!raw) return [];
    const ids = JSON.parse(raw);
    return Array.isArray(ids) ? ids : [];
  } catch {
    return [];
  }
}

export function toggleWatchlist(id: string): boolean {
  if (typeof window === "undefined") return false;
  const ids = getWatchlistIds();
  const idx = ids.indexOf(id);
  let added: boolean;
  if (idx === -1) {
    ids.push(id);
    added = true;
  } else {
    ids.splice(idx, 1);
    added = false;
  }
  localStorage.setItem(WATCHLIST_KEY, JSON.stringify(ids));
  // Notify other components (header badge etc.)
  window.dispatchEvent(new CustomEvent("real-anime:watchlist-changed"));
  return added;
}

export function isInWatchlist(id: string): boolean {
  return getWatchlistIds().includes(id);
}

// ---- Continue watching (localStorage) ----
export function getContinueWatching(): ContinueWatchingEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(CONTINUE_WATCHING_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveContinueWatching(entry: ContinueWatchingEntry): void {
  if (typeof window === "undefined") return;
  const list = getContinueWatching().filter(
    (e) => e.animeId !== entry.animeId
  );
  list.unshift(entry);
  // Keep last 12
  localStorage.setItem(
    CONTINUE_WATCHING_KEY,
    JSON.stringify(list.slice(0, 12))
  );
  window.dispatchEvent(new CustomEvent("real-anime:continue-changed"));
}

export function clearContinueWatching(animeId?: string): void {
  if (typeof window === "undefined") return;
  if (animeId) {
    const list = getContinueWatching().filter((e) => e.animeId !== animeId);
    localStorage.setItem(CONTINUE_WATCHING_KEY, JSON.stringify(list));
  } else {
    localStorage.removeItem(CONTINUE_WATCHING_KEY);
  }
  window.dispatchEvent(new CustomEvent("real-anime:continue-changed"));
}

// ---- Admin auth (client-side gate; real check happens in API route too) ----
export const ADMIN_PASSWORD_ENV_VAR = "ADMIN_PASSWORD";
export const DEFAULT_ADMIN_PASSWORD = "realanime"; // override via Vercel env var
