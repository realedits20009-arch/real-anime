// Core domain types for Real Anime

export type AnimeType = "TV" | "Movie" | "OVA" | "ONA" | "Special";
export type AiringStatus = "Airing" | "Completed" | "Upcoming";
export type AgeRating = "G" | "PG" | "PG-13" | "R" | "R+";
export type SubDub = "Sub" | "Dub" | "Both";
export type Quality = "360p" | "480p" | "720p" | "1080p" | "4K";

export interface VideoSource {
  quality: Quality;
  url: string;
  label?: string; // e.g. "Server 1", "Main"
}

export interface Episode {
  number: number;
  title: string;
  thumbnail?: string;
  duration: string; // "24m"
  subDub: SubDub;
  sources: VideoSource[];
  description?: string;
}

export interface Anime {
  id: string;
  slug: string;
  title: string;
  alternativeTitle?: string;
  poster: string; // portrait poster URL
  banner: string; // wide hero banner URL
  synopsis: string;
  genres: string[];
  type: AnimeType;
  studio: string;
  year: number;
  status: AiringStatus;
  score: number; // 0-10
  ageRating: AgeRating;
  popularityRank?: number;
  trailer?: string; // YouTube URL
  episodes: Episode[];
  // Curated flags for home page rails
  featured?: boolean; // appears in hero slider
  trending?: boolean; // appears in "Trending now"
  topAiring?: boolean; // appears in "Top airing"
  createdAt: string; // ISO date - used for "Recently added"
}

export interface AnimeCatalog {
  anime: Anime[];
}

export interface ContinueWatchingEntry {
  animeId: string;
  episodeNumber: number;
  progress: number; // 0-1
  updatedAt: string;
}

export interface UploadPayload {
  // Subset of Anime that admin can submit; id/slug/createdAt computed server-side
  title: string;
  alternativeTitle?: string;
  poster: string;
  banner: string;
  synopsis: string;
  genres: string[];
  type: AnimeType;
  studio: string;
  year: number;
  status: AiringStatus;
  score: number;
  ageRating: AgeRating;
  popularityRank?: number;
  trailer?: string;
  episodes: Episode[];
  featured?: boolean;
  trending?: boolean;
  topAiring?: boolean;
}

// Standardised genre list used for chips / filters
export const ALL_GENRES = [
  "Action",
  "Adventure",
  "Comedy",
  "Drama",
  "Fantasy",
  "Horror",
  "Mystery",
  "Romance",
  "Sci-Fi",
  "Slice of Life",
  "Sports",
  "Supernatural",
  "Thriller",
  "Ecchi",
  "Mecha",
  "Music",
  "Psychological",
  "School",
  "Shounen",
  "Isekai",
] as const;

export const GENRE_LIST = [...ALL_GENRES];
