import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Real Anime — Stream Anime in HD",
  description:
    "Real Anime is a clean, fast anime streaming experience. Browse trending series, top-airing shows, movies, and OVA across every genre. Built for fans, deployable on Vercel.",
  keywords: [
    "Real Anime",
    "anime streaming",
    "watch anime online",
    "trending anime",
    "anime episodes",
    "subbed anime",
    "dubbed anime",
  ],
  authors: [{ name: "Real Anime" }],
  applicationName: "Real Anime",
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    shortcut: ["/favicon.svg"],
    apple: [{ url: "/favicon.svg" }],
  },
  manifest: undefined,
  openGraph: {
    title: "Real Anime — Stream Anime in HD",
    description:
      "Browse trending series, top-airing shows, movies, and OVA across every genre.",
    siteName: "Real Anime",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Real Anime",
    description: "Stream anime in HD — trending, top-airing, movies and more.",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
