"use client";

import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { HomeView } from "@/components/home-view";
import { DetailView } from "@/components/detail-view";
import { GenreView } from "@/components/genre-view";
import { SearchView } from "@/components/search-view";
import { WatchlistView } from "@/components/watchlist-view";
import { AdminView } from "@/components/admin-view";
import { parseView, type View } from "@/lib/nav";

export default function Home() {
  const [view, setView] = useState<View>({ kind: "home" });
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const update = () => {
      const params = new URLSearchParams(window.location.search);
      setView(parseView(params));
    };
    // Patch history methods so pushState/replaceState (used by next/link)
    // also trigger our router re-render.
    const originalPush = history.pushState;
    const originalReplace = history.replaceState;
    history.pushState = function (...args) {
      const r = originalPush.apply(this, args);
      window.dispatchEvent(new Event("pushstate"));
      return r;
    };
    history.replaceState = function (...args) {
      const r = originalReplace.apply(this, args);
      window.dispatchEvent(new Event("replacestate"));
      return r;
    };
    update();
    setMounted(true);
    window.addEventListener("popstate", update);
    window.addEventListener("pushstate", update);
    window.addEventListener("replacestate", update);
    return () => {
      history.pushState = originalPush;
      history.replaceState = originalReplace;
      window.removeEventListener("popstate", update);
      window.removeEventListener("pushstate", update);
      window.removeEventListener("replacestate", update);
    };
  }, []);

  // Scroll to top on view change (except detail view, which may scroll to episode)
  useEffect(() => {
    if (view.kind !== "detail") {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    } else {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    }
  }, [view]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader />
      <main className="flex-1">
        {!mounted ? (
          <div className="h-[60vh]" />
        ) : (
          <ViewRouter view={view} />
        )}
      </main>
      <SiteFooter />
    </div>
  );
}

function ViewRouter({ view }: { view: View }) {
  switch (view.kind) {
    case "home":
      return <HomeView />;
    case "detail":
      return (
        <DetailView
          slug={view.slug}
          initialEpisode={
            typeof window !== "undefined"
              ? Number(new URLSearchParams(window.location.search).get("ep")) || undefined
              : undefined
          }
        />
      );
    case "genre":
      return <GenreView genre={view.genre} />;
    case "search":
      return <SearchView initialQuery={view.q} />;
    case "watchlist":
      return <WatchlistView />;
    case "admin":
      return <AdminView />;
    default:
      return <HomeView />;
  }
}
