"use client";

import { useEffect, useState } from "react";
import { Flame, Clock, TrendingUp, Sparkles } from "lucide-react";
import type { Anime } from "@/lib/types";
import {
  getFeatured,
  getTrending,
  getTopAiring,
  getRecentlyAdded,
  getAnimeByGenre,
  getAllGenresInUse,
} from "@/lib/anime-store";
import { HeroSlider } from "./hero-slider";
import { AnimeRail } from "./anime-rail";
import { ContinueWatchingRail } from "./continue-watching-rail";
import Link from "next/link";

export function HomeView() {
  const [data, setData] = useState<{
    featured: Anime[];
    trending: Anime[];
    topAiring: Anime[];
    recent: Anime[];
    genres: string[];
  } | null>(null);

  useEffect(() => {
    setData({
      featured: getFeatured(),
      trending: getTrending(),
      topAiring: getTopAiring(),
      recent: getRecentlyAdded(14),
      genres: getAllGenresInUse(),
    });
  }, []);

  if (!data) {
    // Skeleton
    return (
      <div className="space-y-8 py-8">
        <div className="h-[60vh] min-h-[420px] bg-card animate-pulse rounded-lg" />
        <div className="px-4 sm:px-6 lg:px-8 space-y-3">
          <div className="h-8 w-48 bg-card animate-pulse rounded" />
          <div className="flex gap-4 overflow-hidden">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="w-[170px] aspect-[2/3] bg-card animate-pulse rounded-lg shrink-0" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const featured = data.featured.slice(0, 5);
  const trending = data.trending.slice(0, 12);
  const topAiring = data.topAiring.slice(0, 12);
  const recent = data.recent.slice(0, 14);

  // Pick top 5 genres by count
  const genreSections = data.genres
    .map((g) => ({ genre: g, items: getAnimeByGenre(g).slice(0, 8) }))
    .filter((s) => s.items.length >= 2)
    .slice(0, 5);

  return (
    <div className="space-y-8 sm:space-y-10 pb-12">
      {featured.length > 0 && <HeroSlider items={featured} />}

      <div className="space-y-8 sm:space-y-10 pt-2">
        <ContinueWatchingRail />

        <AnimeRail
          title="Trending Now"
          subtitle="Most-watched this week"
          anime={trending}
          icon={<Flame className="h-5 w-5" />}
        />

        <AnimeRail
          title="Top Airing"
          subtitle="Currently broadcasting in Japan"
          anime={topAiring}
          icon={<TrendingUp className="h-5 w-5" />}
        />

        <AnimeRail
          title="Recently Added"
          subtitle="Fresh uploads to the catalog"
          anime={recent}
          icon={<Clock className="h-5 w-5" />}
        />

        {/* By genre sections */}
        {genreSections.map(({ genre, items }) => (
          <AnimeRail
            key={genre}
            title={genre}
            subtitle={`Top ${genre.toLowerCase()} picks`}
            anime={items}
            viewAllHref={`/?genre=${encodeURIComponent(genre)}`}
            icon={<Sparkles className="h-5 w-5" />}
          />
        ))}

        {/* Genre quick-pick grid at the bottom */}
        <section className="px-4 sm:px-6 lg:px-8">
          <div className="rounded-xl border border-border/60 bg-card/40 p-6 sm:p-8">
            <h2 className="text-xl sm:text-2xl font-bold gold-gradient-text mb-1">
              Browse by Genre
            </h2>
            <p className="text-sm text-muted-foreground mb-4">
              Jump straight into your favourite category
            </p>
            <div className="flex flex-wrap gap-2">
              {data.genres.map((g) => (
                <Link
                  key={g}
                  href={`/?genre=${encodeURIComponent(g)}`}
                  className="inline-flex items-center px-3 py-1.5 rounded-full text-sm border border-border/60 bg-background/60 hover:border-gold/60 hover:bg-gold/10 hover:text-gold transition-colors"
                >
                  {g}
                </Link>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
