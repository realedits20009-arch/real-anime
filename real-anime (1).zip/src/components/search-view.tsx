"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { Anime, AnimeType } from "@/lib/types";
import { searchAnime, getAllGenresInUse } from "@/lib/anime-store";
import { AnimeCard } from "./anime-card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Search as SearchIcon } from "lucide-react";
import { navigate } from "@/lib/nav";

interface SearchViewProps {
  initialQuery: string;
}

type SortKey = "relevance" | "score" | "newest" | "az";

export function SearchView({ initialQuery }: SearchViewProps) {
  const [query, setQuery] = useState(initialQuery);
  const [anime, setAnime] = useState<Anime[]>([]);
  const [genres, setGenres] = useState<string[]>([]);
  const [genreFilter, setGenreFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("relevance");

  useEffect(() => {
    setQuery(initialQuery);
    setAnime(searchAnime(initialQuery));
    setGenres(getAllGenresInUse());
  }, [initialQuery]);

  const filtered = useMemo(() => {
    let arr = [...anime];
    if (genreFilter !== "all") {
      arr = arr.filter((a) =>
        a.genres.some((g) => g.toLowerCase() === genreFilter.toLowerCase())
      );
    }
    if (typeFilter !== "all") {
      arr = arr.filter((a) => a.type === typeFilter);
    }
    switch (sort) {
      case "score":
        arr.sort((a, b) => b.score - a.score);
        break;
      case "newest":
        arr.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
        break;
      case "az":
        arr.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "relevance":
      default:
        // already in search order (title match first)
        break;
    }
    return arr;
  }, [anime, genreFilter, typeFilter, sort]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate({ kind: "search", q: query.trim() });
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <header className="space-y-3">
        <nav className="text-sm text-muted-foreground">
          <Link href="/" className="hover:text-gold">Home</Link>
          <span className="mx-1.5">/</span>
          <span className="text-gold">Search</span>
        </nav>
        <h1 className="text-3xl sm:text-4xl font-extrabold gold-gradient-text">
          Search results
        </h1>
        <p className="text-sm text-muted-foreground">
          {anime.length} match{anime.length !== 1 ? "es" : ""} for{" "}
          <span className="text-gold font-semibold">&ldquo;{initialQuery}&rdquo;</span>
        </p>

        {/* Re-search bar */}
        <form onSubmit={onSubmit} className="flex items-center relative max-w-md mt-2">
          <SearchIcon className="absolute left-3 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search another title..."
            className="pl-9 pr-3 bg-card/60"
          />
        </form>
      </header>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Genre</span>
          <Select value={genreFilter} onValueChange={setGenreFilter}>
            <SelectTrigger className="w-[140px] bg-card/60">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All genres</SelectItem>
              {genres.map((g) => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Type</span>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[110px] bg-card/60">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="TV">TV</SelectItem>
              <SelectItem value="Movie">Movie</SelectItem>
              <SelectItem value="OVA">OVA</SelectItem>
              <SelectItem value="ONA">ONA</SelectItem>
              <SelectItem value="Special">Special</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Sort</span>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="w-[140px] bg-card/60">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="relevance">Relevance</SelectItem>
              <SelectItem value="score">Score</SelectItem>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="az">A → Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Results */}
      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-xl font-semibold text-foreground/80">
            No results found.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Try a different keyword or browse by genre.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {filtered.map((a) => (
            <AnimeCard key={a.id} anime={a} />
          ))}
        </div>
      )}
    </div>
  );
}
