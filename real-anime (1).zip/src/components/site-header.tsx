"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Search, Bookmark, Shield, Menu, X, Home as HomeIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useWatchlistIds } from "@/hooks/use-anime-state";
import { navigate, viewToHref } from "@/lib/nav";

export function SiteHeader() {
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const watchlistIds = useWatchlistIds();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (q) navigate({ kind: "search", q });
  };

  return (
    <header
      className={`sticky top-0 z-50 w-full border-b border-border/60 backdrop-blur-xl transition-colors ${
        scrolled ? "bg-background/90 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.7)]" : "bg-background/60"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0 group">
          <img
            src="/logo.svg"
            alt="Real Anime"
            className="h-9 w-auto transition-transform group-hover:scale-[1.03]"
          />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1 text-sm">
          <Link
            href="/"
            className="px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40 transition-colors"
          >
            Home
          </Link>
          <Link
            href="/?genre=Action"
            className="px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40 transition-colors"
          >
            Genres
          </Link>
          <Link
            href="/?watchlist=1"
            className="px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40 transition-colors"
          >
            Watchlist
          </Link>
        </nav>

        {/* Search */}
        <form
          onSubmit={submitSearch}
          className="hidden sm:flex flex-1 max-w-md mx-auto items-center relative"
        >
          <Search className="absolute left-3 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search anime, studio, genre..."
            className="pl-9 pr-3 bg-card/60 border-border/60 focus-visible:border-gold focus-visible:ring-gold/30"
          />
        </form>

        {/* Right actions */}
        <div className="flex items-center gap-1 ml-auto sm:ml-0">
          <Link
            href={viewToHref({ kind: "watchlist" })}
            aria-label="Watchlist"
            className="relative inline-flex h-10 w-10 items-center justify-center rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40 transition-colors"
          >
            <Bookmark className="h-5 w-5" />
            {watchlistIds.length > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 inline-flex items-center justify-center rounded-full bg-gold text-black text-[10px] font-bold gold-glow">
                {watchlistIds.length}
              </span>
            )}
          </Link>
          <Link
            href={viewToHref({ kind: "admin" })}
            aria-label="Admin upload"
            className="hidden sm:inline-flex h-10 w-10 items-center justify-center rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40 transition-colors"
          >
            <Shield className="h-5 w-5" />
          </Link>

          {/* Mobile toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile sheet */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border/60 bg-background/95 backdrop-blur-xl">
          <div className="mx-auto max-w-7xl px-4 py-3 space-y-2">
            <form onSubmit={submitSearch} className="flex items-center relative">
              <Search className="absolute left-3 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search anime..."
                className="pl-9 pr-3 bg-card/60"
              />
            </form>
            <nav className="grid grid-cols-2 gap-1 pt-1">
              <Link
                href="/"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40"
              >
                <HomeIcon className="h-4 w-4" /> Home
              </Link>
              <Link
                href="/?genre=Action"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40"
              >
                <Search className="h-4 w-4" /> Genres
              </Link>
              <Link
                href="/?watchlist=1"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40"
              >
                <Bookmark className="h-4 w-4" /> Watchlist
                {watchlistIds.length > 0 && (
                  <Badge className="ml-auto bg-gold text-black">
                    {watchlistIds.length}
                  </Badge>
                )}
              </Link>
              <Link
                href="/?admin=1"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-foreground/80 hover:text-gold hover:bg-accent/40"
              >
                <Shield className="h-4 w-4" /> Admin
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
