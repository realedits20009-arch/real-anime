"use client";

import Link from "next/link";
import { Star, Play, Bookmark, BookmarkCheck } from "lucide-react";
import { useState } from "react";
import type { Anime } from "@/lib/types";
import { isInWatchlist, toggleWatchlist } from "@/lib/anime-store";
import { watchHref } from "@/lib/nav";
import { Badge } from "@/components/ui/badge";

interface AnimeCardProps {
  anime: Anime;
  compact?: boolean;
}

export function AnimeCard({ anime, compact = false }: AnimeCardProps) {
  const [saved, setSaved] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Avoid hydration mismatch — read localStorage only after mount
  useState(() => {
    setSaved(isInWatchlist(anime.id));
    setMounted(true);
  });

  const onToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const added = toggleWatchlist(anime.id);
    setSaved(added);
  };

  const epCount = anime.episodes.length;
  const href = watchHref(anime.slug);

  return (
    <Link
      href={href}
      className="group relative block w-full overflow-hidden rounded-lg bg-card border border-border/60 hover:border-gold/60 transition-all duration-300 hover:shadow-[0_12px_40px_-12px_rgba(0,0,0,0.8)] hover:-translate-y-1"
    >
      {/* Poster */}
      <div className={`relative ${compact ? "aspect-[2/3]" : "aspect-[2/3]"} overflow-hidden`}>
        <img
          src={anime.poster}
          alt={anime.title}
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {/* gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/20 to-transparent" />

        {/* Top badges */}
        <div className="absolute top-2 left-2 right-2 flex items-start justify-between gap-2">
          <Badge className="bg-gold/95 text-black text-[10px] font-bold uppercase tracking-wide shadow">
            {anime.type}
          </Badge>
          {anime.status === "Airing" && (
            <Badge className="bg-red-600/95 text-white text-[10px] font-bold uppercase shadow">
              • Live
            </Badge>
          )}
        </div>

        {/* Watchlist toggle */}
        {mounted && (
          <button
            onClick={onToggle}
            aria-label={saved ? "Remove from watchlist" : "Add to watchlist"}
            className="absolute bottom-2 right-2 inline-flex h-8 w-8 items-center justify-center rounded-full bg-black/70 backdrop-blur-sm border border-white/10 hover:bg-gold hover:text-black transition-colors"
          >
            {saved ? (
              <BookmarkCheck className="h-4 w-4 text-gold hover:text-black" />
            ) : (
              <Bookmark className="h-4 w-4 text-white" />
            )}
          </button>
        )}

        {/* Score badge */}
        <div className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded-md bg-black/70 backdrop-blur-sm px-1.5 py-0.5 text-[11px] font-semibold text-gold">
          <Star className="h-3 w-3 fill-gold" />
          {anime.score.toFixed(1)}
        </div>

        {/* Hover overlay with play */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="h-14 w-14 rounded-full bg-gold/90 text-black flex items-center justify-center gold-glow-strong">
            <Play className="h-6 w-6 fill-black" />
          </div>
        </div>
      </div>

      {/* Title */}
      <div className="p-2.5 sm:p-3">
        <h3 className="text-sm font-semibold text-foreground line-clamp-1 group-hover:text-gold transition-colors">
          {anime.title}
        </h3>
        <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">
          {epCount > 0 ? `${epCount} episode${epCount > 1 ? "s" : ""}` : "No episodes"} • {anime.year}
        </p>
      </div>
    </Link>
  );
}
