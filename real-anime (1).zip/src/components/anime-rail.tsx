"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Anime } from "@/lib/types";
import { AnimeCard } from "./anime-card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

interface AnimeRailProps {
  title: string;
  subtitle?: string;
  anime: Anime[];
  viewAllHref?: string;
  icon?: React.ReactNode;
}

export function AnimeRail({
  title,
  subtitle,
  anime,
  viewAllHref,
  icon,
}: AnimeRailProps) {
  const ref = useRef<HTMLDivElement>(null);

  if (anime.length === 0) return null;

  const scrollBy = (dir: 1 | -1) => {
    const el = ref.current;
    if (!el) return;
    const amount = Math.round(el.clientWidth * 0.85) * dir;
    el.scrollBy({ left: amount, behavior: "smooth" });
  };

  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2.5">
          {icon && <span className="text-gold">{icon}</span>}
          <div>
            <h2 className="text-xl sm:text-2xl font-bold gold-gradient-text">
              {title}
            </h2>
            {subtitle && (
              <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {viewAllHref && (
            <Link
              href={viewAllHref}
              className="text-xs sm:text-sm font-medium text-gold hover:text-gold-light transition-colors"
            >
              View all →
            </Link>
          )}
          <div className="hidden sm:flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full border border-border/60 hover:border-gold/60 hover:text-gold"
              onClick={() => scrollBy(-1)}
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full border border-border/60 hover:border-gold/60 hover:text-gold"
              onClick={() => scrollBy(1)}
              aria-label="Scroll right"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div
        ref={ref}
        className="flex gap-3 sm:gap-4 overflow-x-auto scrollbar-hide px-4 sm:px-6 lg:px-8 pb-3 scroll-smooth"
      >
        {anime.map((a) => (
          <div
            key={a.id}
            className="shrink-0 w-[140px] sm:w-[170px] md:w-[180px]"
          >
            <AnimeCard anime={a} />
          </div>
        ))}
      </div>
    </section>
  );
}
