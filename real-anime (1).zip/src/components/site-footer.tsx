"use client";

import Link from "next/link";
import { Github, Heart } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border/60 bg-background/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
          <div className="col-span-2 md:col-span-1">
            <img src="/logo.svg" alt="Real Anime" className="h-9 w-auto mb-3" />
            <p className="text-muted-foreground">
              Stream anime in HD. Curated by fans, deployable on Vercel.
            </p>
          </div>

          <div>
            <h4 className="text-gold font-semibold mb-3">Browse</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li><Link href="/" className="hover:text-gold">Home</Link></li>
              <li><Link href="/?genre=Action" className="hover:text-gold">Genres</Link></li>
              <li><Link href="/?watchlist=1" className="hover:text-gold">Watchlist</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-gold font-semibold mb-3">Genres</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li><Link href="/?genre=Action" className="hover:text-gold">Action</Link></li>
              <li><Link href="/?genre=Romance" className="hover:text-gold">Romance</Link></li>
              <li><Link href="/?genre=Isekai" className="hover:text-gold">Isekai</Link></li>
              <li><Link href="/?genre=Shounen" className="hover:text-gold">Shounen</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-gold font-semibold mb-3">Project</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <a
                  href="https://vercel.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-gold"
                >
                  Deploy on Vercel
                </a>
              </li>
              <li>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 hover:text-gold"
                >
                  <Github className="h-4 w-4" /> Source on GitHub
                </a>
              </li>
              <li><Link href="/?admin=1" className="hover:text-gold">Admin Panel</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-border/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <p>
            &copy; {new Date().getFullYear()} Real Anime. Built with Next.js &amp; Tailwind.
          </p>
          <p className="inline-flex items-center gap-1.5">
            Made with <Heart className="h-3 w-3 text-gold fill-gold" /> for anime fans
          </p>
        </div>
      </div>
    </footer>
  );
}
