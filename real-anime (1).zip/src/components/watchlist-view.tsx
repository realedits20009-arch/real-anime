"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import type { Anime } from "@/lib/types";
import { getWatchlist } from "@/lib/anime-store";
import { AnimeCard } from "./anime-card";
import { Button } from "@/components/ui/button";
import { Bookmark } from "lucide-react";

export function WatchlistView() {
  const [anime, setAnime] = useState<Anime[] | null>(null);

  useEffect(() => {
    const update = () => setAnime(getWatchlist());
    update();
    window.addEventListener("real-anime:watchlist-changed", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("real-anime:watchlist-changed", update);
      window.removeEventListener("storage", update);
    };
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <header className="space-y-2">
        <nav className="text-sm text-muted-foreground">
          <Link href="/" className="hover:text-gold">Home</Link>
          <span className="mx-1.5">/</span>
          <span className="text-gold">Watchlist</span>
        </nav>
        <h1 className="text-3xl sm:text-4xl font-extrabold gold-gradient-text">
          My Watchlist
        </h1>
        <p className="text-sm text-muted-foreground">
          Saved on this device. Sign in across devices in a future update.
        </p>
      </header>

      {anime === null ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] bg-card animate-pulse rounded-lg" />
          ))}
        </div>
      ) : anime.length === 0 ? (
        <div className="text-center py-24">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-card border border-border/60 mb-4">
            <Bookmark className="h-8 w-8 text-gold" />
          </div>
          <p className="text-xl font-semibold text-foreground/80">
            Your watchlist is empty
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Tap the bookmark icon on any anime to save it for later.
          </p>
          <Link href="/">
            <Button className="mt-4 bg-gold text-black hover:bg-gold-light">
              Browse anime
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {anime.map((a) => (
            <AnimeCard key={a.id} anime={a} />
          ))}
        </div>
      )}
    </div>
  );
}
