"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { Anime } from "@/lib/types";
import { getAnimeByGenre, getAllGenresInUse } from "@/lib/anime-store";
import { AnimeCard } from "./anime-card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

interface GenreViewProps {
  genre: string;
}

type SortKey = "popularity" | "score" | "newest" | "az";

export function GenreView({ genre }: GenreViewProps) {
  const [anime, setAnime] = useState<Anime[]>([]);
  const [genres, setGenres] = useState<string[]>([]);
  const [sort, setSort] = useState<SortKey>("popularity");

  useEffect(() => {
    setAnime(getAnimeByGenre(genre));
    setGenres(getAllGenresInUse());
  }, [genre]);

  const sorted = useMemo(() => {
    const arr = [...anime];
    switch (sort) {
      case "score":
        return arr.sort((a, b) => b.score - a.score);
      case "newest":
        return arr.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
      case "az":
        return arr.sort((a, b) => a.title.localeCompare(b.title));
      case "popularity":
      default:
        return arr.sort(
          (a, b) => (a.popularityRank ?? 999) - (b.popularityRank ?? 999)
        );
    }
  }, [anime, sort]);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <header className="space-y-3">
        <nav className="text-sm text-muted-foreground">
          <Link href="/" className="hover:text-gold">Home</Link>
          <span className="mx-1.5">/</span>
          <span className="text-gold capitalize">{genre}</span>
        </nav>
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold capitalize gold-gradient-text">
              {genre} Anime
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {anime.length} title{anime.length !== 1 ? "s" : ""} in this genre
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Sort by</span>
            <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
              <SelectTrigger className="w-[160px] bg-card/60 border-border/60">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Popularity</SelectItem>
                <SelectItem value="score">Score</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="az">A → Z</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Genre chips */}
      <div className="flex flex-wrap gap-2">
        <Link
          href="/"
          className="inline-flex items-center px-3 py-1.5 rounded-full text-xs border border-border/60 hover:border-gold/60 hover:text-gold transition-colors"
        >
          All genres
        </Link>
        {genres.map((g) => (
          <Link
            key={g}
            href={`/?genre=${encodeURIComponent(g)}`}
            className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs border transition-colors ${
              g.toLowerCase() === genre.toLowerCase()
                ? "bg-gold text-black border-gold font-semibold"
                : "border-border/60 hover:border-gold/60 hover:text-gold"
            }`}
          >
            {g}
          </Link>
        ))}
      </div>

      {/* Grid */}
      {sorted.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-xl font-semibold text-foreground/80">
            No anime in this genre yet.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Try another genre or upload your own from the admin panel.
          </p>
          <Link href="/?admin=1">
            <Button className="mt-4 bg-gold text-black hover:bg-gold-light">
              Upload Anime
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {sorted.map((a) => (
            <AnimeCard key={a.id} anime={a} />
          ))}
        </div>
      )}
    </div>
  );
}
