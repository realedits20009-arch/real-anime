"use client";

import { useEffect, useRef, useState } from "react";
import { Settings, AlertCircle } from "lucide-react";
import type { Episode, Quality, VideoSource } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface VideoPlayerProps {
  episode: Episode;
  animeId: string;
  animeSlug: string;
  poster?: string;
  onProgress?: (progress: number) => void;
}

const QUALITY_ORDER: Quality[] = ["4K", "1080p", "720p", "480p", "360p"];

export function VideoPlayer({
  episode,
  animeId,
  poster,
  onProgress,
}: VideoPlayerProps) {
  const sources = episode.sources;
  const [activeSrc, setActiveSrc] = useState<VideoSource | null>(
    sources[0] ?? null
  );
  const [error, setError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Reset when episode changes
  useEffect(() => {
    setError(false);
    const next = sources[0] ?? null;
    setActiveSrc(next);
  }, [episode.number, sources]);

  // Apply source when changed
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !activeSrc) return;
    v.src = activeSrc.url;
    v.load();
    v.play().catch(() => {
      // Autoplay may be blocked — that's fine, user can press play
    });
  }, [activeSrc]);

  // Track progress (throttled)
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !onProgress) return;
    let lastReport = 0;
    const onTime = () => {
      const now = Date.now();
      if (now - lastReport < 5000) return;
      lastReport = now;
      if (v.duration && v.duration > 0) {
        onProgress(v.currentTime / v.duration);
      }
    };
    v.addEventListener("timeupdate", onTime);
    return () => v.removeEventListener("timeupdate", onTime);
  }, [onProgress]);

  // Group sources by quality for the dropdown
  const grouped = QUALITY_ORDER.map((q) => ({
    quality: q,
    items: sources.filter((s) => s.quality === q),
  })).filter((g) => g.items.length > 0);

  return (
    <div className="relative w-full overflow-hidden rounded-lg border border-border/60 bg-black aspect-video">
      {activeSrc ? (
        <video
          ref={videoRef}
          controls
          playsInline
          poster={poster}
          className="absolute inset-0 h-full w-full bg-black"
          onError={() => setError(true)}
          onLoadedMetadata={() => setError(false)}
        >
          <source src={activeSrc.url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
          <p className="text-sm">No video source available for this episode.</p>
        </div>
      )}

      {/* Error banner */}
      {error && activeSrc && (
        <div className="absolute top-3 left-3 right-3 sm:right-auto sm:max-w-md bg-destructive/95 text-white px-3 py-2 rounded-md flex items-start gap-2 text-sm shadow-lg">
          <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold">Could not load this source.</p>
            <p className="text-xs opacity-90 mt-0.5">
              Try a different quality or server below.
            </p>
          </div>
        </div>
      )}

      {/* Quality / server picker */}
      {grouped.length > 0 && (
        <div className="absolute bottom-3 right-3 z-10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="sm"
                variant="secondary"
                className="bg-black/70 backdrop-blur-sm border border-white/10 text-white hover:bg-gold hover:text-black"
              >
                <Settings className="h-4 w-4 mr-1" />
                {activeSrc?.quality ?? "Quality"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>Quality &amp; Server</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {grouped.map((g) => (
                <div key={g.quality}>
                  <DropdownMenuLabel className="text-xs uppercase tracking-wide text-muted-foreground">
                    {g.quality}
                  </DropdownMenuLabel>
                  {g.items.map((s, i) => (
                    <DropdownMenuItem
                      key={`${s.quality}-${i}`}
                      onClick={() => {
                        setActiveSrc(s);
                        setError(false);
                      }}
                      className={
                        activeSrc?.url === s.url
                          ? "bg-gold/20 text-gold font-semibold"
                          : ""
                      }
                    >
                      {s.label ?? `Server ${i + 1}`}
                    </DropdownMenuItem>
                  ))}
                </div>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      {/* Episode label overlay */}
      <div className="absolute top-3 left-3 z-10 bg-black/70 backdrop-blur-sm px-2.5 py-1 rounded-md text-xs text-white font-semibold pointer-events-none">
        EP {episode.number}
        {episode.subDub && episode.subDub !== "Sub" && (
          <span className="ml-2 text-gold">{episode.subDub}</span>
        )}
      </div>
    </div>
  );
}
