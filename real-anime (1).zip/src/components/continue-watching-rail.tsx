"use client";

import Link from "next/link";
import { Play, X } from "lucide-react";
import { useContinueWatching } from "@/hooks/use-anime-state";
import { getAllAnime, clearContinueWatching } from "@/lib/anime-store";
import { watchHref } from "@/lib/nav";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export function ContinueWatchingRail() {
  const entries = useContinueWatching();
  const [hidden, setHidden] = useState(false);

  if (hidden || entries.length === 0) return null;

  // Resolve anime data on the client
  const all = typeof window !== "undefined" ? getAllAnime() : [];
  const items = entries
    .map((e) => {
      const anime = all.find((a) => a.id === e.animeId);
      if (!anime) return null;
      const ep = anime.episodes.find((x) => x.number === e.episodeNumber);
      if (!ep) return null;
      return { anime, ep, progress: e.progress };
    })
    .filter(Boolean) as {
    anime: ReturnType<typeof getAllAnime>[number];
    ep: ReturnType<typeof getAllAnime>[number]["episodes"][number];
    progress: number;
  }[];

  if (items.length === 0) return null;

  const onClear = () => {
    clearContinueWatching();
    setHidden(true);
  };

  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold gold-gradient-text">
            Continue Watching
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
            Pick up right where you left off
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClear}
          className="text-muted-foreground hover:text-destructive"
        >
          <X className="h-4 w-4 mr-1" /> Clear
        </Button>
      </div>

      <div className="flex gap-3 sm:gap-4 overflow-x-auto scrollbar-hide px-4 sm:px-6 lg:px-8 pb-3">
        {items.map(({ anime, ep, progress }) => (
          <Link
            key={`${anime.id}-${ep.number}`}
            href={watchHref(anime.slug, ep.number)}
            className="group shrink-0 w-[280px] sm:w-[320px] relative overflow-hidden rounded-lg bg-card border border-border/60 hover:border-gold/60 transition-all duration-300 hover:shadow-[0_12px_40px_-12px_rgba(0,0,0,0.8)] hover:-translate-y-1"
          >
            <div className="relative aspect-video overflow-hidden">
              <img
                src={anime.banner || anime.poster}
                alt={anime.title}
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent" />

              {/* Play button */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="h-12 w-12 rounded-full bg-gold/90 text-black flex items-center justify-center gold-glow-strong">
                  <Play className="h-5 w-5 fill-black" />
                </div>
              </div>

              {/* Episode label */}
              <div className="absolute bottom-2 left-2 right-2">
                <p className="text-[11px] uppercase tracking-wide text-gold font-semibold">
                  Episode {ep.number}
                </p>
                <p className="text-sm font-semibold text-white line-clamp-1">
                  {anime.title}
                </p>
              </div>

              {/* Progress bar */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/40">
                <div
                  className="h-full bg-gold"
                  style={{ width: `${Math.min(100, Math.max(2, progress * 100))}%` }}
                />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
