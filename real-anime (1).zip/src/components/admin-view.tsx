"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Shield,
  Lock,
  Upload,
  Plus,
  Trash2,
  Save,
  Download,
  LogOut,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import type {
  Anime,
  UploadPayload,
  Episode,
  VideoSource,
  Quality,
  AnimeType,
  AiringStatus,
  AgeRating,
  SubDub,
} from "@/lib/types";
import { GENRE_LIST } from "@/lib/types";
import {
  buildAnimeFromPayload,
  saveAdminUpload,
  getAdminUploads,
  deleteAdminUpload,
  getAllAnime,
  DEFAULT_ADMIN_PASSWORD,
} from "@/lib/anime-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

const SESSION_KEY = "real-anime:admin-session";

const QUALITIES: Quality[] = ["4K", "1080p", "720p", "480p", "360p"];

const EMPTY_EPISODE: Episode = {
  number: 1,
  title: "Episode 1",
  duration: "24m",
  subDub: "Sub",
  sources: [{ quality: "1080p", url: "", label: "Main" }],
};

const EMPTY_FORM: UploadPayload = {
  title: "",
  alternativeTitle: "",
  poster: "",
  banner: "",
  synopsis: "",
  genres: [],
  type: "TV",
  studio: "",
  year: new Date().getFullYear(),
  status: "Airing",
  score: 8.0,
  ageRating: "PG-13",
  popularityRank: undefined,
  trailer: "",
  episodes: [{ ...EMPTY_EPISODE }],
  featured: false,
  trending: false,
  topAiring: false,
};

export function AdminView() {
  const [authed, setAuthed] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      if (sessionStorage.getItem(SESSION_KEY) === "1") setAuthed(true);
    } catch {}
  }, []);

  if (!mounted) {
    return <div className="h-screen" />;
  }

  if (!authed) {
    return <AdminLogin onSuccess={() => setAuthed(true)} />;
  }

  return <AdminDashboard onLogout={() => setAuthed(false)} />;
}

// ---------- Admin Login ----------

function AdminLogin({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { toast } = useToast();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Client-side check. The real password lives in NEXT_PUBLIC_ADMIN_PASSWORD
    // (set on Vercel). Falls back to DEFAULT_ADMIN_PASSWORD for local dev.
    const expected =
      process.env.NEXT_PUBLIC_ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;
    if (password === expected) {
      try {
        sessionStorage.setItem(SESSION_KEY, "1");
      } catch {}
      toast({ title: "Welcome back, admin", description: "Upload panel unlocked." });
      onSuccess();
    } else {
      setError("Wrong password. Try again.");
    }
  };

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className="rounded-xl border border-border/60 bg-card/40 p-8 shadow-xl">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="h-14 w-14 rounded-full bg-gold/15 border border-gold/40 flex items-center justify-center mb-3 gold-glow">
            <Shield className="h-7 w-7 text-gold" />
          </div>
          <h1 className="text-2xl font-bold gold-gradient-text">Admin Access</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Enter your admin password to upload and manage anime.
          </p>
        </div>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="password" className="text-sm font-medium">
              Admin Password
            </Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                placeholder="Enter password"
                className="pl-9 bg-background/60"
                autoFocus
              />
            </div>
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {error}
              </p>
            )}
          </div>

          <Button type="submit" className="w-full bg-gold text-black hover:bg-gold-light font-semibold">
            Unlock Panel
          </Button>
        </form>

        <div className="mt-6 pt-4 border-t border-border/40 text-xs text-muted-foreground space-y-1">
          <p className="font-semibold text-foreground/80">Default password:</p>
          <code className="block bg-background/60 px-2 py-1 rounded text-gold">
            {DEFAULT_ADMIN_PASSWORD}
          </code>
          <p className="mt-2">
            On Vercel, set <code className="text-gold">NEXT_PUBLIC_ADMIN_PASSWORD</code> env var to override.
          </p>
        </div>

        <Link
          href="/"
          className="block text-center text-xs text-muted-foreground hover:text-gold mt-4"
        >
          ← Back to site
        </Link>
      </div>
    </div>
  );
}

// ---------- Admin Dashboard ----------

function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const [form, setForm] = useState<UploadPayload>({ ...EMPTY_FORM });
  const [uploads, setUploads] = useState<Anime[]>([]);
  const [showExisting, setShowExisting] = useState(true);
  const { toast } = useToast();

  const refreshUploads = () => setUploads(getAdminUploads());

  useEffect(() => {
    refreshUploads();
  }, []);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      toast({ title: "Title is required", variant: "destructive" });
      return;
    }
    if (!form.poster.trim()) {
      toast({ title: "Poster URL is required", variant: "destructive" });
      return;
    }
    if (form.episodes.length === 0) {
      toast({ title: "Add at least one episode", variant: "destructive" });
      return;
    }
    // Validate that each episode has at least one source with a URL
    const badEp = form.episodes.find(
      (ep) => !ep.sources.some((s) => s.url.trim().length > 0)
    );
    if (badEp) {
      toast({
        title: `Episode ${badEp.number} needs at least one video URL`,
        variant: "destructive",
      });
      return;
    }
    const anime = buildAnimeFromPayload(form);
    saveAdminUpload(anime);
    refreshUploads();
    toast({
      title: "Anime uploaded!",
      description: `${anime.title} is now live on your site.`,
    });
    setForm({ ...EMPTY_FORM });
  };

  const onDelete = (id: string) => {
    deleteAdminUpload(id);
    refreshUploads();
    toast({ title: "Anime deleted", description: "Removed from your uploads." });
  };

  const onExport = () => {
    const all = getAllAnime();
    const blob = new Blob([JSON.stringify({ anime: all }, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "real-anime-catalog.json";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Catalog exported", description: "Commit this JSON to GitHub to share uploads." });
  };

  const update = <K extends keyof UploadPayload>(key: K, value: UploadPayload[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-gold/15 border border-gold/40 flex items-center justify-center">
            <Shield className="h-5 w-5 text-gold" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold gold-gradient-text">
              Admin Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">
              Upload anime with manual video links — no backend required.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={onExport} variant="outline" size="sm" className="border-border/60 hover:border-gold/60 hover:text-gold">
            <Download className="h-4 w-4 mr-1.5" /> Export JSON
          </Button>
          <Button
            onClick={() => {
              try {
                sessionStorage.removeItem(SESSION_KEY);
              } catch {}
              onLogout();
            }}
            variant="outline"
            size="sm"
            className="border-border/60 hover:border-destructive/60 hover:text-destructive"
          >
            <LogOut className="h-4 w-4 mr-1.5" /> Logout
          </Button>
        </div>
      </header>

      {/* Upload form */}
      <form onSubmit={onSubmit} className="rounded-xl border border-border/60 bg-card/40 p-5 sm:p-6 space-y-6">
        <div className="flex items-center gap-2 pb-1">
          <Upload className="h-5 w-5 text-gold" />
          <h2 className="text-lg font-bold">Upload New Anime</h2>
        </div>

        {/* Core info */}
        <section className="space-y-4">
          <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
            Core Information
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Title *">
              <Input
                value={form.title}
                onChange={(e) => update("title", e.target.value)}
                placeholder="e.g. Frieren: Beyond Journey's End"
                className="bg-background/60"
              />
            </Field>
            <Field label="Alternative Title (optional)">
              <Input
                value={form.alternativeTitle || ""}
                onChange={(e) => update("alternativeTitle", e.target.value)}
                placeholder="e.g. 葬送のフリーレン"
                className="bg-background/60"
              />
            </Field>
            <Field label="Poster URL * (portrait 2:3)">
              <Input
                value={form.poster}
                onChange={(e) => update("poster", e.target.value)}
                placeholder="https://...jpg"
                className="bg-background/60"
              />
            </Field>
            <Field label="Banner URL (wide 16:9)">
              <Input
                value={form.banner}
                onChange={(e) => update("banner", e.target.value)}
                placeholder="https://...jpg"
                className="bg-background/60"
              />
            </Field>
          </div>

          <Field label="Synopsis">
            <Textarea
              value={form.synopsis}
              onChange={(e) => update("synopsis", e.target.value)}
              placeholder="A short summary that appears on the detail page..."
              className="bg-background/60 min-h-[100px]"
            />
          </Field>

          <Field label="Genres (multi-select)">
            <div className="flex flex-wrap gap-2 pt-1">
              {GENRE_LIST.map((g) => {
                const selected = form.genres.includes(g);
                return (
                  <button
                    key={g}
                    type="button"
                    onClick={() =>
                      update(
                        "genres",
                        selected
                          ? form.genres.filter((x) => x !== g)
                          : [...form.genres, g]
                      )
                    }
                    className={`px-2.5 py-1 rounded-full text-xs border transition-colors ${
                      selected
                        ? "bg-gold text-black border-gold font-semibold"
                        : "border-border/60 hover:border-gold/60 hover:text-gold"
                    }`}
                  >
                    {g}
                  </button>
                );
              })}
            </div>
          </Field>
        </section>

        <Separator />

        {/* Studio & year */}
        <section className="space-y-4">
          <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
            Studio &amp; Release
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Field label="Type">
              <SelectField
                value={form.type}
                onChange={(v) => update("type", v as AnimeType)}
                options={["TV", "Movie", "OVA", "ONA", "Special"]}
              />
            </Field>
            <Field label="Studio">
              <Input
                value={form.studio}
                onChange={(e) => update("studio", e.target.value)}
                placeholder="e.g. MAPPA"
                className="bg-background/60"
              />
            </Field>
            <Field label="Year">
              <Input
                type="number"
                value={form.year}
                onChange={(e) => update("year", Number(e.target.value))}
                className="bg-background/60"
              />
            </Field>
            <Field label="Status">
              <SelectField
                value={form.status}
                onChange={(v) => update("status", v as AiringStatus)}
                options={["Airing", "Completed", "Upcoming"]}
              />
            </Field>
          </div>
        </section>

        <Separator />

        {/* Rating & age */}
        <section className="space-y-4">
          <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
            Rating &amp; Age
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Field label="Score (0-10)">
              <Input
                type="number"
                step="0.1"
                min="0"
                max="10"
                value={form.score}
                onChange={(e) => update("score", Number(e.target.value))}
                className="bg-background/60"
              />
            </Field>
            <Field label="Age Rating">
              <SelectField
                value={form.ageRating}
                onChange={(v) => update("ageRating", v as AgeRating)}
                options={["G", "PG", "PG-13", "R", "R+"]}
              />
            </Field>
            <Field label="Popularity Rank (optional)">
              <Input
                type="number"
                value={form.popularityRank ?? ""}
                onChange={(e) =>
                  update(
                    "popularityRank",
                    e.target.value ? Number(e.target.value) : undefined
                  )
                }
                placeholder="e.g. 5"
                className="bg-background/60"
              />
            </Field>
            <Field label="Trailer URL (YouTube)">
              <Input
                value={form.trailer || ""}
                onChange={(e) => update("trailer", e.target.value)}
                placeholder="https://youtube.com/watch?v=..."
                className="bg-background/60"
              />
            </Field>
          </div>
        </section>

        <Separator />

        {/* Curated flags */}
        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
            Home Page Placement
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <ToggleCard
              label="Featured (Hero)"
              description="Show in the rotating hero slider on home"
              checked={!!form.featured}
              onChange={(v) => update("featured", v)}
            />
            <ToggleCard
              label="Trending Now"
              description="Show in the Trending rail"
              checked={!!form.trending}
              onChange={(v) => update("trending", v)}
            />
            <ToggleCard
              label="Top Airing"
              description="Show in the Top Airing rail"
              checked={!!form.topAiring}
              onChange={(v) => update("topAiring", v)}
            />
          </div>
        </section>

        <Separator />

        {/* Episodes */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
              Episodes &amp; Video URLs
            </h3>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() =>
                update("episodes", [
                  ...form.episodes,
                  {
                    ...EMPTY_EPISODE,
                    number: form.episodes.length + 1,
                    title: `Episode ${form.episodes.length + 1}`,
                  },
                ])
              }
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              <Plus className="h-4 w-4 mr-1" /> Add Episode
            </Button>
          </div>

          <div className="space-y-3">
            {form.episodes.map((ep, idx) => (
              <EpisodeEditor
                key={idx}
                episode={ep}
                index={idx}
                onChange={(updated) => {
                  const next = [...form.episodes];
                  next[idx] = updated;
                  update("episodes", next);
                }}
                onRemove={() => {
                  const next = form.episodes.filter((_, i) => i !== idx);
                  // Renumber
                  next.forEach((e, i) => (e.number = i + 1));
                  update("episodes", next);
                }}
              />
            ))}
          </div>
        </section>

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => setForm({ ...EMPTY_FORM })}
            className="border-border/60"
          >
            Reset
          </Button>
          <Button type="submit" className="bg-gold text-black hover:bg-gold-light font-semibold">
            <Save className="h-4 w-4 mr-1.5" /> Publish Anime
          </Button>
        </div>
      </form>

      {/* Existing uploads */}
      <section className="rounded-xl border border-border/60 bg-card/40 overflow-hidden">
        <button
          onClick={() => setShowExisting((v) => !v)}
          className="w-full px-5 py-4 flex items-center justify-between hover:bg-accent/30 transition-colors"
        >
          <div className="flex items-center gap-2">
            {showExisting ? (
              <ChevronDown className="h-4 w-4 text-gold" />
            ) : (
              <ChevronRight className="h-4 w-4 text-gold" />
            )}
            <h2 className="text-lg font-bold">My Uploads</h2>
            <Badge className="bg-gold/15 text-gold border border-gold/30">
              {uploads.length}
            </Badge>
          </div>
          <span className="text-xs text-muted-foreground">
            Stored in this browser
          </span>
        </button>

        {showExisting && (
          <div className="border-t border-border/60">
            {uploads.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-muted-foreground">
                No uploads yet. Use the form above to add your first anime.
              </p>
            ) : (
              <ScrollArea className="max-h-[480px]">
                <ul className="divide-y divide-border/40">
                  {uploads.map((a) => (
                    <li
                      key={a.id}
                      className="px-5 py-3 flex items-center gap-4 hover:bg-accent/20"
                    >
                      <img
                        src={a.poster}
                        alt={a.title}
                        className="h-16 w-12 object-cover rounded border border-border/60"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold truncate">{a.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {a.type} • {a.year} • {a.episodes.length} ep •{" "}
                          <span className="text-gold">{a.score.toFixed(1)}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Link href={`/?anime=${encodeURIComponent(a.slug)}`}>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="hover:text-gold"
                          >
                            View
                          </Button>
                        </Link>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onDelete(a.id)}
                          className="hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            )}
          </div>
        )}
      </section>

      {/* Tip card */}
      <div className="rounded-lg border border-gold/30 bg-gold/5 p-4 flex items-start gap-3">
        <CheckCircle2 className="h-5 w-5 text-gold shrink-0 mt-0.5" />
        <div className="text-sm">
          <p className="font-semibold text-gold">Tip: persist uploads across devices</p>
          <p className="text-foreground/80 mt-1">
            Click <strong>Export JSON</strong> to download your current catalog (seed + uploads),
            then commit it to your GitHub repo. On Vercel, your uploads will appear for everyone.
            Use the <code className="text-gold">NEXT_PUBLIC_ADMIN_PASSWORD</code> env var to lock the panel.
          </p>
        </div>
      </div>
    </div>
  );
}

// ---------- Episode editor (sub-component) ----------

function EpisodeEditor({
  episode,
  index,
  onChange,
  onRemove,
}: {
  episode: Episode;
  index: number;
  onChange: (ep: Episode) => void;
  onRemove: () => void;
}) {
  const update = <K extends keyof Episode>(key: K, value: Episode[K]) => {
    onChange({ ...episode, [key]: value });
  };

  const updateSource = (sIdx: number, patch: Partial<VideoSource>) => {
    const next = [...episode.sources];
    next[sIdx] = { ...next[sIdx], ...patch };
    onChange({ ...episode, sources: next });
  };

  const addSource = () => {
    onChange({
      ...episode,
      sources: [
        ...episode.sources,
        { quality: "720p", url: "", label: `Server ${episode.sources.length + 1}` },
      ],
    });
  };

  const removeSource = (sIdx: number) => {
    onChange({
      ...episode,
      sources: episode.sources.filter((_, i) => i !== sIdx),
    });
  };

  return (
    <div className="rounded-lg border border-border/60 bg-background/40 p-4 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-gold text-black font-bold text-sm">
            {episode.number}
          </span>
          <span className="text-sm font-semibold">Episode {episode.number}</span>
        </div>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          onClick={onRemove}
          className="hover:text-destructive"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Field label="Title">
          <Input
            value={episode.title}
            onChange={(e) => update("title", e.target.value)}
            placeholder={`Episode ${episode.number}`}
            className="bg-background/60"
          />
        </Field>
        <Field label="Duration">
          <Input
            value={episode.duration}
            onChange={(e) => update("duration", e.target.value)}
            placeholder="24m"
            className="bg-background/60"
          />
        </Field>
        <Field label="Sub / Dub">
          <SelectField
            value={episode.subDub}
            onChange={(v) => update("subDub", v as SubDub)}
            options={["Sub", "Dub", "Both"]}
          />
        </Field>
      </div>

      {/* Sources */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-xs text-muted-foreground">Video sources</Label>
          <Button
            type="button"
            size="sm"
            variant="ghost"
            onClick={addSource}
            className="h-7 text-xs hover:text-gold"
          >
            <Plus className="h-3 w-3 mr-1" /> Add source
          </Button>
        </div>
        <div className="space-y-2">
          {episode.sources.map((s, sIdx) => (
            <div key={sIdx} className="grid grid-cols-12 gap-2 items-center">
              <div className="col-span-3 sm:col-span-2">
                <SelectField
                  value={s.quality}
                  onChange={(v) => updateSource(sIdx, { quality: v as Quality })}
                  options={QUALITIES}
                  compact
                />
              </div>
              <div className="col-span-4 sm:col-span-3">
                <Input
                  value={s.label || ""}
                  onChange={(e) => updateSource(sIdx, { label: e.target.value })}
                  placeholder="Label"
                  className="bg-background/60 h-9 text-sm"
                />
              </div>
              <div className="col-span-4 sm:col-span-6">
                <Input
                  value={s.url}
                  onChange={(e) => updateSource(sIdx, { url: e.target.value })}
                  placeholder="https://...mp4 or .m3u8"
                  className="bg-background/60 h-9 text-sm"
                />
              </div>
              <div className="col-span-1 flex justify-end">
                {episode.sources.length > 1 && (
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={() => removeSource(sIdx)}
                    className="h-9 w-9 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Small field helpers ----------

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function SelectField({
  value,
  onChange,
  options,
  compact = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
  compact?: boolean;
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={`bg-background/60 ${compact ? "h-9 text-sm" : ""}`}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o} value={o}>
            {o}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function ToggleCard({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div
      className={`rounded-lg border p-3 transition-colors ${
        checked
          ? "border-gold/60 bg-gold/10"
          : "border-border/60 bg-background/40"
      }`}
    >
      <div className="flex items-center justify-between">
        <Label className="text-sm font-semibold cursor-pointer">{label}</Label>
        <Switch checked={checked} onCheckedChange={onChange} />
      </div>
      <p className="text-xs text-muted-foreground mt-1">{description}</p>
    </div>
  );
}
