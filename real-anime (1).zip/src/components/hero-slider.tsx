"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { Play, Star, Info, ChevronLeft, ChevronRight } from "lucide-react";
import type { Anime } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { watchHref } from "@/lib/nav";

interface HeroSliderProps {
  items: Anime[];
}

export function HeroSlider({ items }: HeroSliderProps) {
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = items.length;

  const next = useCallback(() => {
    setIdx((i) => (i + 1) % count);
  }, [count]);
  const prev = () => setIdx((i) => (i - 1 + count) % count);

  useEffect(() => {
    if (paused || count <= 1) return;
    const t = setInterval(next, 7000);
    return () => clearInterval(t);
  }, [paused, count, next]);

  if (count === 0) return null;

  const current = items[idx];

  return (
    <section
      className="relative w-full overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-label="Featured anime"
    >
      {/* Background image */}
      <div className="relative h-[60vh] min-h-[420px] sm:h-[68vh] sm:min-h-[520px] w-full">
        {items.map((a, i) => (
          <div
            key={a.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              i === idx ? "opacity-100" : "opacity-0"
            }`}
            aria-hidden={i !== idx}
          >
            <img
              src={a.banner || a.poster}
              alt={a.title}
              className="absolute inset-0 h-full w-full object-cover object-top"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
          </div>
        ))}

        {/* Content */}
        <div className="absolute inset-0 flex items-end sm:items-center">
          <div className="mx-auto max-w-7xl w-full px-4 sm:px-6 lg:px-8 pb-10 sm:pb-0">
            <div className="max-w-2xl space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="bg-gold text-black font-bold uppercase">
                  Featured
                </Badge>
                <Badge variant="outline" className="border-gold/40 text-gold uppercase">
                  {current.type}
                </Badge>
                {current.status === "Airing" && (
                  <Badge className="bg-red-600 text-white uppercase">Airing Now</Badge>
                )}
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)]">
                <span className="gold-gradient-text">{current.title}</span>
              </h1>

              {current.alternativeTitle && (
                <p className="text-sm text-gold-light/80 font-medium">
                  {current.alternativeTitle}
                </p>
              )}

              <div className="flex flex-wrap items-center gap-3 text-sm">
                <span className="inline-flex items-center gap-1 text-gold font-semibold">
                  <Star className="h-4 w-4 fill-gold" />
                  {current.score.toFixed(1)}
                </span>
                <span className="text-foreground/70">{current.year}</span>
                <span className="text-foreground/70">{current.studio}</span>
                <span className="text-foreground/70">
                  {current.episodes.length} ep{current.episodes.length > 1 ? "s" : ""}
                </span>
                <span className="text-foreground/70 hidden sm:inline">
                  {current.genres.slice(0, 3).join(" • ")}
                </span>
              </div>

              <p className="text-sm sm:text-base text-foreground/80 line-clamp-3 sm:line-clamp-4 max-w-xl">
                {current.synopsis}
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <Link href={watchHref(current.slug, 1)}>
                  <Button
                    size="lg"
                    className="bg-gold text-black hover:bg-gold-light font-bold group"
                  >
                    <Play className="h-5 w-5 fill-black mr-1 group-hover:scale-110 transition-transform" />
                    Watch Now
                  </Button>
                </Link>
                <Link href={watchHref(current.slug)}>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-gold/40 text-gold hover:bg-gold/10 hover:text-gold hover:border-gold"
                  >
                    <Info className="h-5 w-5 mr-1" />
                    More Info
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Arrows */}
        {count > 1 && (
          <>
            <button
              onClick={prev}
              aria-label="Previous slide"
              className="absolute left-2 top-1/2 -translate-y-1/2 hidden sm:inline-flex h-10 w-10 items-center justify-center rounded-full bg-black/40 backdrop-blur-sm border border-white/10 hover:bg-gold hover:text-black transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={next}
              aria-label="Next slide"
              className="absolute right-2 top-1/2 -translate-y-1/2 hidden sm:inline-flex h-10 w-10 items-center justify-center rounded-full bg-black/40 backdrop-blur-sm border border-white/10 hover:bg-gold hover:text-black transition-colors"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </>
        )}

        {/* Dots */}
        {count > 1 && (
          <div className="absolute bottom-4 right-4 flex items-center gap-2">
            {items.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                aria-label={`Go to slide ${i + 1}`}
                className={`h-2 rounded-full transition-all ${
                  i === idx ? "w-8 bg-gold" : "w-2 bg-white/40 hover:bg-white/70"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
