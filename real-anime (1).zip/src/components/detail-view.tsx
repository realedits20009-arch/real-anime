"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Star,
  Calendar,
  Tv,
  Building2,
  Bookmark,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  Play,
  ListVideo,
  Info,
  Film,
} from "lucide-react";
import type { Anime, ContinueWatchingEntry } from "@/lib/types";
import {
  getAnimeBySlug,
  getRelatedAnime,
  isInWatchlist,
  toggleWatchlist,
  saveContinueWatching,
} from "@/lib/anime-store";
import { watchHref, navigate } from "@/lib/nav";
import { VideoPlayer } from "./video-player";
import { AnimeRail } from "./anime-rail";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

interface DetailViewProps {
  slug: string;
  initialEpisode?: number;
}

export function DetailView({ slug, initialEpisode }: DetailViewProps) {
  const [anime, setAnime] = useState<Anime | null>(null);
  const [episodeNumber, setEpisodeNumber] = useState<number>(initialEpisode ?? 1);
  const [saved, setSaved] = useState(false);
  const [related, setRelated] = useState<Anime[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const a = getAnimeBySlug(slug);
    setAnime(a ?? null);
    if (a) {
      const validEp = a.episodes.find((e) => e.number === episodeNumber)
        ? episodeNumber
        : a.episodes[0]?.number ?? 1;
      setEpisodeNumber(validEp);
      setRelated(getRelatedAnime(a, 12));
      setSaved(isInWatchlist(a.id));
    }
    setMounted(true);
  }, [slug, episodeNumber, initialEpisode]);

  const currentEpisode = useMemo(() => {
    if (!anime) return null;
    return anime.episodes.find((e) => e.number === episodeNumber) ?? anime.episodes[0] ?? null;
  }, [anime, episodeNumber]);

  if (!anime) {
    if (!mounted) {
      return (
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          <div className="h-[60vh] bg-card animate-pulse rounded-lg" />
          <div className="h-8 w-64 bg-card animate-pulse rounded" />
          <div className="h-4 w-full bg-card animate-pulse rounded" />
          <div className="h-4 w-3/4 bg-card animate-pulse rounded" />
        </div>
      );
    }
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <p className="text-xl font-semibold text-foreground/80">Anime not found.</p>
        <p className="text-sm text-muted-foreground mt-2">
          The title you&apos;re looking for isn&apos;t in the catalog.
        </p>
        <Link href="/">
          <Button className="mt-4 bg-gold text-black hover:bg-gold-light">
            Back to Home
          </Button>
        </Link>
      </div>
    );
  }

  const onToggleSave = () => {
    const added = toggleWatchlist(anime.id);
    setSaved(added);
  };

  const onProgress = (progress: number) => {
    const entry: ContinueWatchingEntry = {
      animeId: anime.id,
      episodeNumber,
      progress,
      updatedAt: new Date().toISOString(),
    };
    saveContinueWatching(entry);
  };

  const goToEpisode = (n: number) => {
    setEpisodeNumber(n);
    // Update URL without full reload
    if (typeof window !== "undefined") {
      const url = watchHref(anime.slug, n);
      window.history.replaceState({}, "", url);
    }
    // Scroll to player
    if (typeof document !== "undefined") {
      document.getElementById("player-top")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const epIdx = anime.episodes.findIndex((e) => e.number === episodeNumber);
  const prevEp = epIdx > 0 ? anime.episodes[epIdx - 1] : null;
  const nextEp =
    epIdx >= 0 && epIdx < anime.episodes.length - 1
      ? anime.episodes[epIdx + 1]
      : null;

  return (
    <div className="space-y-8 pb-12">
      {/* Banner header */}
      <div className="relative w-full overflow-hidden">
        <div className="absolute inset-0 h-[40vh] sm:h-[46vh]">
          <img
            src={anime.banner || anime.poster}
            alt={anime.title}
            className="absolute inset-0 h-full w-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        </div>

        <div className="relative pt-[28vh] sm:pt-[34vh]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row gap-5 sm:items-end">
              {/* Poster */}
              <div className="hidden sm:block w-44 lg:w-52 shrink-0 -mt-16">
                <div className="aspect-[2/3] rounded-lg overflow-hidden border-2 border-gold/40 shadow-2xl gold-glow">
                  <img
                    src={anime.poster}
                    alt={anime.title}
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>

              <div className="flex-1 space-y-3">
                <nav className="text-xs text-muted-foreground">
                  <Link href="/" className="hover:text-gold">Home</Link>
                  <span className="mx-1.5">/</span>
                  <span className="text-gold">{anime.title}</span>
                </nav>

                <div className="flex flex-wrap items-center gap-2">
                  <Badge className="bg-gold text-black font-bold uppercase">{anime.type}</Badge>
                  <Badge variant="outline" className="border-gold/40 text-gold uppercase">
                    {anime.status}
                  </Badge>
                  <Badge variant="outline" className="border-border/60 text-foreground/80">
                    {anime.ageRating}
                  </Badge>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white drop-shadow">
                  <span className="gold-gradient-text">{anime.title}</span>
                </h1>
                {anime.alternativeTitle && (
                  <p className="text-sm text-gold-light/80 font-medium">
                    {anime.alternativeTitle}
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-4 text-sm">
                  <span className="inline-flex items-center gap-1.5 text-gold font-semibold">
                    <Star className="h-4 w-4 fill-gold" />
                    {anime.score.toFixed(1)}
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-foreground/80">
                    <Calendar className="h-4 w-4 text-gold" />
                    {anime.year}
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-foreground/80">
                    <Tv className="h-4 w-4 text-gold" />
                    {anime.episodes.length} ep
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-foreground/80">
                    <Building2 className="h-4 w-4 text-gold" />
                    {anime.studio}
                  </span>
                  {anime.popularityRank && (
                    <span className="text-foreground/80">
                      Rank #{anime.popularityRank}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  {anime.genres.map((g) => (
                    <Link
                      key={g}
                      href={`/?genre=${encodeURIComponent(g)}`}
                      className="inline-flex items-center px-2.5 py-1 rounded-full text-xs border border-border/60 hover:border-gold/60 hover:text-gold transition-colors"
                    >
                      {g}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Player + Episode list */}
      <div id="player-top" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Player column */}
        <div className="lg:col-span-2 space-y-4">
          {currentEpisode ? (
            <>
              <VideoPlayer
                episode={currentEpisode}
                animeId={anime.id}
                animeSlug={anime.slug}
                poster={anime.banner}
                onProgress={onProgress}
              />

              {/* Now playing + nav */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-wide text-gold font-semibold">
                    Now playing
                  </p>
                  <h2 className="text-lg font-bold text-foreground">
                    Episode {currentEpisode.number}: {currentEpisode.title}
                  </h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {currentEpisode.duration} • {currentEpisode.subDub}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!prevEp}
                    onClick={() => prevEp && goToEpisode(prevEp.number)}
                    className="border-border/60 hover:border-gold/60 hover:text-gold"
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" /> Prev
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!nextEp}
                    onClick={() => nextEp && goToEpisode(nextEp.number)}
                    className="border-border/60 hover:border-gold/60 hover:text-gold"
                  >
                    Next <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>

              {currentEpisode.description && (
                <p className="text-sm text-foreground/80 leading-relaxed">
                  {currentEpisode.description}
                </p>
              )}
            </>
          ) : (
            <div className="aspect-video rounded-lg bg-card border border-border/60 flex items-center justify-center text-muted-foreground">
              <p className="text-sm">No episodes available yet.</p>
            </div>
          )}

          <Separator />

          {/* Synopsis & info */}
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <Info className="h-5 w-5 text-gold" />
              <h2 className="text-xl font-bold gold-gradient-text">Synopsis</h2>
            </div>
            <p className="text-sm sm:text-base text-foreground/85 leading-relaxed">
              {anime.synopsis}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
              <InfoRow label="Type" value={anime.type} />
              <InfoRow label="Studio" value={anime.studio} />
              <InfoRow label="Released" value={String(anime.year)} />
              <InfoRow label="Status" value={anime.status} />
              <InfoRow label="Age Rating" value={anime.ageRating} />
              <InfoRow label="Score" value={`${anime.score.toFixed(1)} / 10`} />
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <Button
                onClick={onToggleSave}
                variant={saved ? "default" : "outline"}
                className={
                  saved
                    ? "bg-gold text-black hover:bg-gold-light"
                    : "border-gold/40 text-gold hover:bg-gold/10"
                }
              >
                {saved ? (
                  <>
                    <BookmarkCheck className="h-4 w-4 mr-1.5" /> In Watchlist
                  </>
                ) : (
                  <>
                    <Bookmark className="h-4 w-4 mr-1.5" /> Add to Watchlist
                  </>
                )}
              </Button>
              {anime.trailer && (
                <a href={anime.trailer} target="_blank" rel="noreferrer">
                  <Button variant="outline" className="border-border/60 hover:border-gold/60 hover:text-gold">
                    <Film className="h-4 w-4 mr-1.5" /> Watch Trailer
                  </Button>
                </a>
              )}
            </div>
          </section>
        </div>

        {/* Episode list sidebar */}
        <aside className="lg:col-span-1 space-y-4">
          <div className="rounded-lg border border-border/60 bg-card/40 overflow-hidden">
            <div className="px-4 py-3 border-b border-border/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ListVideo className="h-5 w-5 text-gold" />
                <h3 className="font-semibold">Episodes</h3>
              </div>
              <span className="text-xs text-muted-foreground">
                {anime.episodes.length} total
              </span>
            </div>
            <ScrollArea className="h-[60vh]">
              <ul className="divide-y divide-border/40">
                {anime.episodes.map((ep) => {
                  const active = ep.number === episodeNumber;
                  return (
                    <li key={ep.number}>
                      <button
                        onClick={() => goToEpisode(ep.number)}
                        className={`w-full text-left px-4 py-3 flex items-start gap-3 transition-colors ${
                          active
                            ? "bg-gold/15 text-gold"
                            : "hover:bg-accent/40"
                        }`}
                      >
                        <div
                          className={`shrink-0 h-9 w-9 rounded-md flex items-center justify-center font-bold text-sm ${
                            active
                              ? "bg-gold text-black"
                              : "bg-background/60 text-foreground/70"
                          }`}
                        >
                          {ep.number}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${active ? "text-gold" : ""}`}>
                            {ep.title}
                          </p>
                          <p className="text-[11px] text-muted-foreground mt-0.5">
                            {ep.duration} • {ep.subDub} • {ep.sources.length} source{ep.sources.length !== 1 ? "s" : ""}
                          </p>
                        </div>
                        {active && (
                          <Play className="h-4 w-4 fill-gold text-gold shrink-0 mt-1" />
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </ScrollArea>
          </div>
        </aside>
      </div>

      {/* Related anime */}
      {related.length > 0 && (
        <AnimeRail
          title="Related Anime"
          subtitle="Because you watched this"
          anime={related}
          icon={<Play className="h-5 w-5" />}
        />
      )}

      {/* Bottom CTA: back to browse */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex justify-center">
        <Button
          variant="outline"
          onClick={() => navigate({ kind: "home" })}
          className="border-border/60 hover:border-gold/60 hover:text-gold"
        >
          <ChevronLeft className="h-4 w-4 mr-1.5" /> Back to Browse
        </Button>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border/40 bg-background/40 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p className="text-sm font-semibold text-foreground/90 mt-0.5">{value}</p>
    </div>
  );
}
