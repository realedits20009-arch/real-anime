"use client";

import { useEffect, useState } from "react";
import {
  getWatchlistIds,
  getContinueWatching,
} from "@/lib/anime-store";
import type { ContinueWatchingEntry } from "@/lib/types";

// Subscribe to watchlist changes (used by header badge)
export function useWatchlistIds(): string[] {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    const update = () => setIds(getWatchlistIds());
    update();
    window.addEventListener("real-anime:watchlist-changed", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("real-anime:watchlist-changed", update);
      window.removeEventListener("storage", update);
    };
  }, []);
  return ids;
}

export function useContinueWatching(): ContinueWatchingEntry[] {
  const [list, setList] = useState<ContinueWatchingEntry[]>([]);
  useEffect(() => {
    const update = () => setList(getContinueWatching());
    update();
    window.addEventListener("real-anime:continue-changed", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("real-anime:continue-changed", update);
      window.removeEventListener("storage", update);
    };
  }, []);
  return list;
}

// Force a remount when the URL changes (used by main page router)
export function useUrlKey(): string {
  const [key, setKey] = useState<string>("");
  useEffect(() => {
    const update = () => setKey(window.location.search);
    update();
    window.addEventListener("popstate", update);
    return () => window.removeEventListener("popstate", update);
  }, []);
  return key;
}
